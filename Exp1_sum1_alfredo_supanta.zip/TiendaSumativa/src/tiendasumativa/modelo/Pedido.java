/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tiendasumativa.modelo;

import java.util.ArrayList;
import java.util.List;
import tiendasumativa.modelo.Producto;
import tiendasumativa.vista.VistaPedido;

/**
 *
 * @author alfre
 */
public class Pedido implements VistaPedido{
    private List<Producto> productos;

    public Pedido() {
        productos = new ArrayList<>();
    }

    public void agregarProducto(Producto producto) {
        productos.add(producto);
    }

    public void eliminarProducto(Producto producto) {
        productos.remove(producto);
    }

    public List<Producto> getProductos() {
        return productos;
    }

    @Override
    public void mostrarDetallesPedido(Pedido pedido) {
        System.out.println("Detalles del Pedido:");
        for (Producto producto : pedido.getProductos()) {
            System.out.println(" - " + producto.getNombre() + ": $" + producto.getPrecio());
        }
    }
}
