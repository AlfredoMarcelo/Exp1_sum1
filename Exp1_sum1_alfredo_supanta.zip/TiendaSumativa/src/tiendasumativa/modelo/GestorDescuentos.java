/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tiendasumativa.modelo;

import tiendasumativa.vista.VistaDescuento;

/**
 *
 * @author alfre
 */
public class GestorDescuentos implements VistaDescuento{
     private static GestorDescuentos instancia;

    private GestorDescuentos() {
    }

    public static GestorDescuentos obtenerInstancia() {
        if (instancia == null) {
            instancia = new GestorDescuentos();
        }
        return instancia;
    }

    public double aplicarDescuento(Producto producto, double descuento) {
        return producto.getPrecio() * (1 - descuento);
    }

    @Override
    public void mostrarPrecioDescontado(Producto producto, double precioDescontado) {
        System.out.println("El precio con descuento de " + producto.getNombre() + " es $" + precioDescontado);
    }
}
