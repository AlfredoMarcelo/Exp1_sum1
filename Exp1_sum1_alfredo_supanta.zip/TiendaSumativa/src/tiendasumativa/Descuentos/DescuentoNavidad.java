/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tiendasumativa.Descuentos;

import tiendasumativa.Component;
import tiendasumativa.Decorator;

/**
 *
 * @author alfre
 */
public abstract class DescuentoNavidad extends Decorator{
    public DescuentoNavidad(Component componente){
        super(componente);
    }

    @Override
    public double aplicarDescuento(double precio) {
        return super.aplicarDescuento(precio)* 0.5; 
    }
}
