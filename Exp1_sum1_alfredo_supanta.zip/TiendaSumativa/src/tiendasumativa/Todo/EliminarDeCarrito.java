/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tiendasumativa.Todo;

import tiendasumativa.Command;

/**
 *
 * @author alfre
 */
public class EliminarDeCarrito implements Command{

    @Override
    public void ejecutar() {
        System.out.println("Eliminar producto de carrito");
    }
    
}
